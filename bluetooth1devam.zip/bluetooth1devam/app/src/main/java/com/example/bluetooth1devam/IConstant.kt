package com.example.bluetooth1devam

interface IConstant {
    object DEFAULTS{
        const val GPS_CODE = 1
    }
}